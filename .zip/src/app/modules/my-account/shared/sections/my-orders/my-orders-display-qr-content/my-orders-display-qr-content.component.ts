import {ChangeDetectionStrategy, Component} from '@angular/core';

@Component({
  selector: 'app-my-orders-display-qr-content',
  imports: [],
  templateUrl: './my-orders-display-qr-content.component.html',
  styleUrl: './my-orders-display-qr-content.component.css',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MyOrdersDisplayQrContentComponent {}
