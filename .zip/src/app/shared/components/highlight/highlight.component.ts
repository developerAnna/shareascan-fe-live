import {Component} from '@angular/core';

@Component({
  selector: 'app-highlight',
  imports: [],
  templateUrl: './highlight.component.html',
  styleUrl: './highlight.component.css',
})
export class HighlightComponent {}
