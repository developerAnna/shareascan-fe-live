export interface INavbarLink {
  path: string;
  translationKey: string;
}
