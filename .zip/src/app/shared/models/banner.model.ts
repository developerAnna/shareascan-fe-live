export interface IBanner {
  title: string;
  subtitle: string;
  description: string;
  image: string;
  bgColor?: string;
  id?: number;
}
