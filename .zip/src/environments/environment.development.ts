// export const environment = {
//  API_URL: 'http://localhost:8000',
//  IMAGEKIT_URL: 'https://ik.imagekit.io/shareascan',
//  IMAGEKIT_PUBLIC_KEY: 'public_nZYcke71WDDW4n8Lp/4NS1LKsVE=',
//  IMAGEKIT_PRIVATE_KEY: 'private_SvWZIP4KdYYGCopLh5/5Vh3Yw7U=',
// };

export const environment = {
  API_URL: 'https://admin.shareascan.com',
  IMAGEKIT_URL: 'https://ik.imagekit.io/shareascan',
  IMAGEKIT_PUBLIC_KEY: 'public_nZYcke71WDDW4n8Lp/4NS1LKsVE=',
  IMAGEKIT_PRIVATE_KEY: 'private_SvWZIP4KdYYGCopLh5/5Vh3Yw7U=',
};
