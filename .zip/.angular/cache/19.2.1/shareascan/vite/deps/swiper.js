import {
  Swiper
} from "./chunk-GZALUTLL.js";
import "./chunk-B4BLUBMO.js";
import "./chunk-WDMUDEB6.js";
export {
  Swiper,
  Swiper as default
};
